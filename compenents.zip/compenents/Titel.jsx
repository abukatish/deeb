import React from 'react'

export default function Titel() {
  return (
    <div>
        <h1 id='smartHouseTitel'>Smart house</h1>
    </div>
  )
}
