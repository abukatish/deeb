import React from 'react'
import { useState } from 'react';
import './style.css';

export default function OnOffBtn(props) {
  const[color,setColor]=useState('red')
  const switchOnOff=()=>{
        if(color=='red'){
          {
            props.device('on')  
            setColor('green')
          }
        }
        else{
          props.device('off')
          setColor('red')
        }
  }
  return (
    <div>
      {console.log(props.roomsDevices.nameOfDevice)}
            
    
        <button id='changeColor' onClick={switchOnOff} style={{backgroundColor: color}}>{props.roomsDevices.nameOfDevice}</button>
    </div>
  )
}
