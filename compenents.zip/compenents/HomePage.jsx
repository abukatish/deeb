import React from 'react'
import Titel from './Titel'
import { Link } from 'react-router-dom'
import ShowRooms from './ShowRooms'
import './style.css'

export default function HomePage(props) {
  
  return (
    <div className='homePageMain'>
      
      <div>

        <Titel/>
      </div>
<div>
     <Link to='/addroom'><button id='plusBtn'>+</button></Link>  <br />

</div>
<br /><br />
<div className='showRoomsCompenent'>
{
        props.roomsArr.map((val,ind,arr)=>{
           return <ShowRooms name={val.roomName} color={val.color} arr={arr} roomData={val.roomData} index={ind} roomIndex={props.roomIndex} resetFunc={props.resetFunc}/>
        })
      }
</div>

    </div>
  )
}
