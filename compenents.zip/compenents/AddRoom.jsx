import React, { useState } from 'react'
import Titel from './Titel'
import { Provider } from '../contextApi'
import { Consumer } from '../contextApi'
import { useNavigate } from 'react-router-dom'
import { Link } from 'react-router-dom'
import './style.css'




export default function AddRoom(props) {
    const[roomName,setRoomName]=useState('')
    const[roomColor,setRoomColor]=useState('')
    const nev =useNavigate();



    const checkAddRoom=()=>{
                   
            let selectedRoom=document.getElementById('selectedRoom').value;
  
            console.log(selectedRoom)
            if(roomName.length>=1 && roomName.length<=5 && selectedRoom!=0)
            {
              {props.addRooms(roomName,roomColor,selectedRoom)}
              nev('/')
            }
            else{
              nev('/')
              alert('error')
            }
           

    }
  return (
    <div>
        <Titel/>
        <select required id='selectedRoom' className='selectedRoom'>
        <option value="" disabled selected> select new room</option>
             <option value="sleepRoom"> sleeproom</option>
            <option value="bathRoom">Bathroom</option>
            <option value="kitchen">kitchen</option>

        </select><br /><br/><br />
       
        <input className='inputStyleAddRoom' onChange={(e)=>{setRoomName(e.target.value)}} placeholder='Enter room name'/><br /><br />
        <input className='inputStyleAddRoom' onChange={(e)=>{setRoomColor(e.target.value)}} placeholder='Enter your color' /><br /><br />

        <button onClick={checkAddRoom} id='creatBtn'>צור</button><br /><br /><br />



    </div>
  )
}
