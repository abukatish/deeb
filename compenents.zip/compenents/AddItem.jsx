import React from 'react'
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';

export default function AddItem(props) {

  
  const addTheItemChecker=()=>{
    let selectedItem = document.getElementById('selectedItem').value;
 
    if(props.arr[props.index].roomDevices.length >4  ){
      alert(`you can't add more than 5 items`)
      selectedItem =''
              
         }
         if(selectedItem == 'boiler' && props.arr[props.index].roomData !='bathRoom'){
                 
          alert('only to bathroom can added')
        }
         

          
          else{
                    let cnt=0;
                   props.arr[props.index].roomDevices.forEach((val) => {
                      if(val.nameOfDevice == 'sterioSesteme' && selectedItem == 'sterioSesteme')
                         
                      {
                        if(cnt>1){
                         
                          
                          return alert('can not add more than one sterio sesteme')
                        }
                        cnt++;
                        console.log(cnt)
                      }
                   });
              props.selectedItems(props.index,selectedItem,cnt);
              props.flagFunc()
              props.selectedtFunc()
              props.selected(selectedItem)
             }
 
            

 
            console.log(selectedItem)
            console.log(props.index , selectedItem)
        
             
         
           

           
         


  }
  return (
    <div>
      <div>

        <select required id='selectedItem' className='selectItem'>
            <option value="" disabled selected>select product</option>
            <option value="condeshen">condeshen</option>
            <option value="lamp">lamp</option>
            <option value="sterioSesteme">sterioSesteme</option>
            <option value="boiler">boiler</option>

        </select>
        <br /><br />

          


        <button onClick={addTheItemChecker} id='addItemBtn2'>add</button>
      </div>
      <div>
       
      </div>
           
    </div>

  )
}
