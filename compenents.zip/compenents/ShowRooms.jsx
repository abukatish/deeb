import React from 'react'
import { Link, useNavigate } from 'react-router-dom'
import './style.css'


export default function (props) {
  const nav= useNavigate()

  const goToRoom=()=>{
    props.roomIndex(props.index)
    
    nav('/room')
  }
  return (
    <div  className='roomStyle'>

          <button id='roomBtn'  onClick={goToRoom} style={{backgroundColor: props.color }}   >{props.name}</button>  <br />

    </div>
  )
}


// import React from 'react';
// import { useState } from 'react';
//  import { useNavigate } from 'react-router-dom'
//  import { Link } from 'react-router-dom';
// import Rooms from './Rooms';
// import './style.css'



// export default function ShowRooms(props) {
//   const[flag,setFlag]=useState(false);



//   const sheckFlag =()=>{
//     if(flag == false){
//      }
//     if(flag == true){
//        return <Rooms name={props.name} roomSelected={props.roomData} index={props.index}/>
//     }
//   }
 
   
//     const showTheRoom=()=>{
//       console.log(props.index)
//       setFlag(true)
//        // props.roomFunc(props.index)
//     }
  
//   return (
//     <div className='roomStyle'>
//             <div>

//         <button onClick={showTheRoom } id='roomBtn'  style={{backgroundColor: props.color }}   >{props.name}</button>
//         {/* <Link to='/room'><button>+</button></Link>  <br /> */}

        
//             </div>
//         {/* <Rooms name={props.name} roomSelected={props.roomData}/> */}

//         <br />
//                 {sheckFlag()}
//      </div>
//   )
// }
