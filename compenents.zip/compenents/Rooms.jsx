import React from 'react'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import OnOffBtn from './OnOffBtn'
import AddItem from './AddItem'
import './style.css'
import Titel from './Titel'

export default function Room(props) {
  const[flagOnOff,setFlagOnOff]=useState(false)
  const[selectedAnd,setSelect]=useState('')

  const device=(str)=>{
    if(str == 'on')
    props.deviceStatuse('true')
    else if(str == 'off')
    props.deviceStatuse('false')
  }

  
  const selctedFu=(str)=>{
    
    setSelect(str)
  }

  const selectedtFunc=()=>{
      setFlagOnOff(true)
  }

   const [flag,setFlag]=useState(false)

  const changeFlag=()=>{
      setFlag(!flag)
  }
  
  const showOnOff =()=>{
     
    if(flagOnOff == true){
      console.log(props.roomsArr[props.ind].roomDevices)
        return  props.roomsArr[props.ind].roomDevices.map((val,index)=>{
          console.log(val)
            return <OnOffBtn   roomsDevices={val} index={index} device={device}/>          })

      //  return <OnOffBtn  select={selectedAnd} arrOnOff={props.arrOnOff}/>
 
    }
  }
 
 
  const showAddItem=()=>{
  
    if(flag == true){
   
      return <AddItem index={props.ind} arr={props.roomsArr} selectedItems={props.selectedItems}   flagFunc={changeFlag} selectedtFunc={selectedtFunc} selected={selctedFu} countSterio={props.countSterio}/>

    }

       
  }
  const showInSide =()=>{
    setFlagOnOff(true)
  }
  
  
  return (
    <div>
      <div>
        <Titel/>
      </div>
      <div>

        <h1 className='headerRoom'>Room type: {props.roomsArr[props.ind].roomData}</h1>
        <h1 className='headerRoom'>Name of room :{props.roomsArr[props.ind].roomName} </h1>

        <button onClick={changeFlag} className='addItemBtn'>Add item</button> 
        <button onClick={showInSide} className='addItemBtn'>show details</button>
      </div>
      <div>
        {showAddItem()}
      </div>
      <div>
          {showOnOff()}
      </div>
      
    </div>
  )
}
